#if DEBUG
import UIKit
import WebKit

/// Test-only (Debug builds, launch argument "-tour"): walks through the main
/// screens, saves a picture of each one and the list of iPhone voices to the
/// app's Documents/tour folder. The CI build copies them out so we can check
/// the iPhone version without owning an iPhone. Not compiled into App Store builds.
enum TestTour {
    private static var handler: TourHandler?

    static var folder: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("tour", isDirectory: true)
    }

    static func startIfRequested(on webView: WKWebView) {
        if ProcessInfo.processInfo.arguments.contains("-video") {
            webView.configuration.userContentController.addUserScript(
                WKUserScript(source: videoScript, injectionTime: .atDocumentEnd, forMainFrameOnly: true))
            return
        }
        guard ProcessInfo.processInfo.arguments.contains("-tour") else { return }
        try? FileManager.default.removeItem(at: folder)
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        try? SpeechService.voiceReport().write(to: folder.appendingPathComponent("voices.txt"), atomically: true, encoding: .utf8)
        let handler = TourHandler(webView: webView)
        self.handler = handler
        webView.configuration.userContentController.add(handler, name: "tour")
        webView.configuration.userContentController.addUserScript(
            WKUserScript(source: script, injectionTime: .atDocumentEnd, forMainFrameOnly: true))
    }

    /// Slow, human-paced walk-through used to record the App Review screen recording.
    private static let videoScript = """
    (async function () {
      const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
      const q = (s) => document.querySelector(s);
      const click = (s) => { const e = q(s); if (e) { e.scrollIntoView({ block: 'center', behavior: 'smooth' }); e.click(); return true; } return false; };
      const clickText = (s, re) => { const e = [...document.querySelectorAll(s)].find((x) => re.test(x.textContent)); if (e) { e.scrollIntoView({ block: 'center' }); e.click(); } };
      const setVal = (el, v) => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })); };
      try {
        await sleep(6000);
        click('.welcome-action .continue-button'); await sleep(3500);
        click('.new-profile-button'); await sleep(3000);
        const name = q('input[placeholder]');
        if (name) { name.focus(); const n = 'Adam'; for (let i = 1; i <= n.length; i++) { setVal(name, n.slice(0, i)); await sleep(350); } name.blur(); }
        await sleep(1500);
        click('.language-field'); await sleep(3500);
        const list = q('.language-list'); if (list) { list.scrollBy({ top: 250, behavior: 'smooth' }); await sleep(1500); list.scrollBy({ top: -250, behavior: 'smooth' }); await sleep(1200); }
        clickText('.language-list button', /Arabic/); await sleep(3000);
        const box = q('.legal-check input'); if (box && !box.checked) box.click();
        await sleep(2000);
        click('.continue-button.solid'); await sleep(5000);
        window.scrollBy({ top: 350, behavior: 'smooth' }); await sleep(2500);
        window.scrollTo({ top: 0, behavior: 'smooth' }); await sleep(2000);
        click('.official-exam-hero'); await sleep(4000);
        click('.mode-btn.test'); await sleep(5000);
        for (let i = 0; i < 7; i++) {
          const answers = [...document.querySelectorAll('.answer-select')];
          if (answers.length) { const a = answers[i % answers.length]; a.scrollIntoView({ block: 'center', behavior: 'smooth' }); await sleep(900); a.click(); }
          await sleep(3500);
          window.scrollTo({ top: 0, behavior: 'smooth' });
          click('.quiz-nav .next'); await sleep(2500);
        }
      } catch (e) { }
    })();
    """

    private static let script = """
    (async function () {
      const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
      const log = (m) => window.webkit.messageHandlers.tour.postMessage({ cmd: 'log', text: String(m) });
      const snap = (name) => new Promise((r) => { window.__tourSnapDone = r; window.webkit.messageHandlers.tour.postMessage({ cmd: 'snap', name }); });
      const q = (s) => document.querySelector(s);
      const click = (s) => { const e = q(s); if (e) { e.click(); return true; } log('missing ' + s); return false; };
      const clickText = (s, re) => { const e = [...document.querySelectorAll(s)].find((x) => re.test(x.textContent)); if (e) e.click(); else log('missing ' + s + ' ' + re); };
      const type = (el, v) => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })); };
      try {
        await sleep(3500); await snap('01_welcome');
        click('.welcome-action .continue-button'); await sleep(1500); await snap('02_learners');
        click('.new-profile-button'); await sleep(1500);
        const name = q('input[placeholder]'); if (name) type(name, 'Adam'); else log('missing name input');
        click('.language-field'); await sleep(1500); await snap('03_languages');
        clickText('.language-list button', /Arabic/); await sleep(2000);
        const box = q('.legal-check input'); if (box && !box.checked) box.click();
        await sleep(600); await snap('04_new_learner_arabic');
        click('.continue-button.solid'); await sleep(3000); await snap('05_dashboard_arabic');
        click('.official-exam-hero'); await sleep(1500); await snap('06_exam_style');
        click('.mode-btn.test'); await sleep(3000); await snap('07_exam_question_1');
        let picture = false;
        for (let i = 0; i < 40 && !picture; i++) {
          if (q('.question-image')) { await sleep(1200); await snap('08_picture_question'); picture = true; break; }
          click('.answer-select'); await sleep(400);
          click('.quiz-nav .next'); await sleep(900);
        }
        if (!picture) log('no picture question in first 40');
        log('questions in bank: ' + (document.body.innerText.length > 0));
      } catch (e) { log('error ' + e); }
      window.webkit.messageHandlers.tour.postMessage({ cmd: 'done' });
    })();
    """
}

private final class TourHandler: NSObject, WKScriptMessageHandler {
    weak var webView: WKWebView?
    private var logLines: [String] = []
    init(webView: WKWebView) { self.webView = webView }

    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any], let cmd = body["cmd"] as? String else { return }
        switch cmd {
        case "snap":
            let name = body["name"] as? String ?? "shot"
            webView?.takeSnapshot(with: nil) { [weak self] image, _ in
                if let data = image?.pngData() {
                    try? data.write(to: TestTour.folder.appendingPathComponent("\(name).png"))
                }
                self?.webView?.evaluateJavaScript("window.__tourSnapDone && window.__tourSnapDone()", completionHandler: nil)
            }
        case "log":
            logLines.append(body["text"] as? String ?? "")
            writeLog()
        case "done":
            logLines.append("DONE")
            writeLog()
        default: break
        }
    }

    private func writeLog() {
        try? logLines.joined(separator: "\n").write(to: TestTour.folder.appendingPathComponent("log.txt"), atomically: true, encoding: .utf8)
    }
}
#endif
