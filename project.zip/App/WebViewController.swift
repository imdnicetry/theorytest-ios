import UIKit
import WebKit

/// Hosts the same web app as the Android build and offers it the same
/// `window.Android` bridge, so the web code runs unchanged on iPhone.
final class WebViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate {
    private var webView: WKWebView!
    private var launchOverlay: UIView?
    private let speech = SpeechService()
    private let reminders = ReminderService()
    private var pendingSchedule: String?
    private var voiceAlertShown = Set<String>()

    static let brandGreen = UIColor(red: 8 / 255, green: 127 / 255, blue: 91 / 255, alpha: 1)   // #087F5B
    static let splashBackground = UIColor(red: 0, green: 63 / 255, blue: 49 / 255, alpha: 1)    // #003F31
    static let pageBackground = UIColor(red: 248 / 255, green: 247 / 255, blue: 241 / 255, alpha: 1)

    /// The Android bridge API, implemented on top of WKScriptMessageHandler.
    private static let bridgeScript = """
    (function () {
      function post(msg) { window.webkit.messageHandlers.native.postMessage(msg); }
      window.Android = {
        speak: function (text, language, rate) { post({ cmd: 'speak', text: String(text || ''), language: String(language || 'en-IE'), rate: Number(rate) || 1 }); },
        stopSpeech: function () { post({ cmd: 'stopSpeech' }); },
        setNotificationSchedule: function (schedule) { post({ cmd: 'setNotificationSchedule', schedule: String(schedule) }); },
        saveTheoryTest: function (profileId, date, time, location) { post({ cmd: 'saveTheoryTest', profileId: String(profileId || ''), date: String(date || ''), time: String(time || ''), location: String(location || '') }); },
        requestNotifications: function () { post({ cmd: 'requestNotifications' }); },
        appReady: function () { post({ cmd: 'appReady' }); }
      };
    })();
    """

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white

        let config = WKWebViewConfiguration()
        config.setURLSchemeHandler(LocalSchemeHandler(), forURLScheme: LocalSchemeHandler.scheme)
        config.websiteDataStore = .default()              // keeps localStorage between launches
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.userContentController.addUserScript(
            WKUserScript(source: Self.bridgeScript, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        config.userContentController.add(WeakMessageHandler(self), name: "native")

        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = Self.pageBackground
        webView.scrollView.backgroundColor = Self.pageBackground
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.scrollView.bounces = false
        webView.allowsBackForwardNavigationGestures = false
        webView.translatesAutoresizingMaskIntoConstraints = false

        // Green strip behind the status bar (same look as Android).
        let statusStrip = UIView()
        statusStrip.backgroundColor = Self.brandGreen
        statusStrip.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(statusStrip)
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            statusStrip.topAnchor.constraint(equalTo: view.topAnchor),
            statusStrip.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            statusStrip.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            statusStrip.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            webView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            webView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            webView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
        ])

        // Swipe from the left edge = Android back button.
        let edgeSwipe = UIScreenEdgePanGestureRecognizer(target: self, action: #selector(edgeSwipe(_:)))
        edgeSwipe.edges = .left
        view.addGestureRecognizer(edgeSwipe)

        addLaunchOverlay()

        speech.onFinished = { [weak self] in
            DispatchQueue.main.async { self?.dispatch("window.dispatchEvent(new Event('native-speech-ended'))") }
        }
        speech.onMissingVoice = { [weak self] language in
            DispatchQueue.main.async { self?.showMissingVoice(language) }
        }

        #if DEBUG
        TestTour.startIfRequested(on: webView)
        #endif
        webView.load(URLRequest(url: LocalSchemeHandler.startURL))
        DispatchQueue.main.asyncAfter(deadline: .now() + 6) { [weak self] in self?.hideLaunchOverlay() }
        DispatchQueue.main.async { [weak self] in self?.reminders.restore() }
    }

    // MARK: - Launch screen (logo on dark green until the first screen is painted)

    private func addLaunchOverlay() {
        let overlay = UIView()
        overlay.backgroundColor = Self.splashBackground
        overlay.translatesAutoresizingMaskIntoConstraints = false
        let logo = UIImageView(image: UIImage(named: "SplashLogo"))
        logo.contentMode = .scaleAspectFit
        logo.translatesAutoresizingMaskIntoConstraints = false
        overlay.addSubview(logo)
        view.addSubview(overlay)
        NSLayoutConstraint.activate([
            overlay.topAnchor.constraint(equalTo: view.topAnchor),
            overlay.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            overlay.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            overlay.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            logo.centerXAnchor.constraint(equalTo: overlay.centerXAnchor),
            logo.centerYAnchor.constraint(equalTo: overlay.centerYAnchor),
            logo.widthAnchor.constraint(equalToConstant: 160),
            logo.heightAnchor.constraint(equalToConstant: 160),
        ])
        launchOverlay = overlay
    }

    private func hideLaunchOverlay() {
        guard let overlay = launchOverlay else { return }
        launchOverlay = nil
        UIView.animate(withDuration: 0.15, animations: { overlay.alpha = 0 }, completion: { _ in overlay.removeFromSuperview() })
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        // Safety net if the page never calls Android.appReady().
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { [weak self] in self?.hideLaunchOverlay() }
    }

    // If iOS kills the web process in the background, reload instead of showing a blank page.
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        webView.load(URLRequest(url: LocalSchemeHandler.startURL))
    }

    // Links to websites (e.g. rsa.ie) open in Safari, not inside the app.
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { return decisionHandler(.allow) }
        if url.scheme == LocalSchemeHandler.scheme || url.scheme == "about" || url.scheme == "blob" || url.scheme == "data" {
            return decisionHandler(.allow)
        }
        UIApplication.shared.open(url)
        decisionHandler(.cancel)
    }

    // target="_blank" links
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url { UIApplication.shared.open(url) }
        return nil
    }

    // Camera for the profile photo (iOS shows its own permission prompt).
    @available(iOS 15.0, *)
    func webView(_ webView: WKWebView, requestMediaCapturePermissionFor origin: WKSecurityOrigin,
                 initiatedByFrame frame: WKFrameInfo, type: WKMediaCaptureType,
                 decisionHandler: @escaping (WKPermissionDecision) -> Void) {
        decisionHandler(type == .camera ? .grant : .deny)
    }

    // window.alert / confirm from the page, as native dialogs.
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        present(alert, animated: true)
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        present(alert, animated: true)
    }

    // MARK: - Bridge

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any], let cmd = body["cmd"] as? String else { return }
        switch cmd {
        case "speak":
            speech.speak(body["text"] as? String ?? "",
                         language: body["language"] as? String ?? "en-IE",
                         rate: (body["rate"] as? NSNumber)?.doubleValue ?? 1)
        case "stopSpeech":
            speech.stop()
        case "setNotificationSchedule":
            let schedule = body["schedule"] as? String ?? "off"
            if schedule == "off" {
                reminders.apply("off")
                dispatchNotificationPermission(false)
            } else {
                reminders.ensurePermission { [weak self] granted in
                    guard let self else { return }
                    if granted { self.reminders.apply(schedule) } else { self.reminders.apply("off") }
                    self.dispatchNotificationPermission(granted)
                }
            }
        case "saveTheoryTest":
            guard let id = body["profileId"] as? String, !id.isEmpty else { return }
            let defaults = UserDefaults.standard
            defaults.set(body["date"] as? String ?? "", forKey: "user_\(id)_theoryDate")
            defaults.set(body["time"] as? String ?? "", forKey: "user_\(id)_theoryTime")
            defaults.set(body["location"] as? String ?? "", forKey: "user_\(id)_theoryLocation")
        case "requestNotifications":
            reminders.ensurePermission { [weak self] granted in self?.dispatchNotificationPermission(granted) }
        case "appReady":
            hideLaunchOverlay()
        default:
            break
        }
    }

    private func dispatchNotificationPermission(_ granted: Bool) {
        let status = granted ? "granted" : "denied"
        dispatch("window.dispatchEvent(new CustomEvent('notification-permission-result',{detail:'\(status)'}))")
    }

    private func dispatch(_ js: String) {
        webView?.evaluateJavaScript(js, completionHandler: nil)
    }

    @objc private func edgeSwipe(_ gesture: UIScreenEdgePanGestureRecognizer) {
        if gesture.state == .ended { dispatch("window.dispatchEvent(new Event('android-back'))") }
    }

    private func showMissingVoice(_ language: String) {
        let base = String(language.split(separator: "-").first ?? "")
        guard voiceAlertShown.insert(base).inserted, presentedViewController == nil else { return }
        let name = Locale(identifier: "en").localizedString(forLanguageCode: base) ?? language
        let alert = UIAlertController(
            title: "\(name) voice not available",
            message: "This iPhone has no \(name) voice. You can still read the \(name) text on screen, and listen in English.\n\nTo check for more voices: Settings › Accessibility › Spoken Content › Voices.",
            preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}

/// Avoids the retain cycle WKUserContentController -> handler -> web view.
private final class WeakMessageHandler: NSObject, WKScriptMessageHandler {
    weak var target: WKScriptMessageHandler?
    init(_ target: WKScriptMessageHandler) { self.target = target }
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        target?.userContentController(controller, didReceive: message)
    }
}
