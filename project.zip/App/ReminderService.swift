import UIKit
import UserNotifications

/// Study reminders - same schedules as Android: "off", "1h", "2h", "3h", "daily:HH:MM".
final class ReminderService {
    static let scheduleKey = "notif_schedule"
    private static let idPrefix = "study-reminder-"
    private let center = UNUserNotificationCenter.current()
    private let defaults = UserDefaults.standard

    private static let messages = [
        "Time to study! Open Driver Zone Ireland 🚗",
        "A few questions a day keeps the fail away ✅",
        "Your Irish theory test is waiting — 5 min is enough! 🇮🇪",
        "Keep your streak alive — open Driver Zone now 📚",
        "Quick practice session? Let's go! 🏁",
    ]

    /// Asks iOS for permission when needed. Calls back with true when reminders can be shown.
    func ensurePermission(_ completion: @escaping (Bool) -> Void) {
        center.getNotificationSettings { settings in
            switch settings.authorizationStatus {
            case .authorized, .provisional, .ephemeral:
                DispatchQueue.main.async { completion(true) }
            case .notDetermined:
                self.center.requestAuthorization(options: [.alert, .sound, .badge]) { granted, _ in
                    DispatchQueue.main.async { completion(granted) }
                }
            default:
                // Denied before: iOS will not ask again, so open the app's Settings page.
                DispatchQueue.main.async {
                    if let url = URL(string: UIApplication.openSettingsURLString) {
                        UIApplication.shared.open(url)
                    }
                    completion(false)
                }
            }
        }
    }

    func apply(_ schedule: String) {
        defaults.set(schedule, forKey: Self.scheduleKey)
        center.getPendingNotificationRequests { requests in
            let ours = requests.map(\.identifier).filter { $0.hasPrefix(Self.idPrefix) }
            self.center.removePendingNotificationRequests(withIdentifiers: ours)
            guard schedule != "off" else { return }
            if schedule.hasPrefix("daily:") {
                let parts = schedule.dropFirst("daily:".count).split(separator: ":")
                var time = DateComponents()
                time.hour = Int(parts.first ?? "20") ?? 20
                time.minute = parts.count > 1 ? Int(parts[1]) ?? 0 : 0
                let trigger = UNCalendarNotificationTrigger(dateMatching: time, repeats: true)
                self.add(id: "daily", trigger: trigger)
            } else {
                let hours: Double
                switch schedule {
                case "1h": hours = 1
                case "2h": hours = 2
                case "3h": hours = 3
                default: return
                }
                let trigger = UNTimeIntervalNotificationTrigger(timeInterval: hours * 3600, repeats: true)
                self.add(id: "repeat", trigger: trigger)
            }
        }
    }

    /// Re-apply the saved schedule at launch (also picks a fresh message).
    func restore() {
        let saved = defaults.string(forKey: Self.scheduleKey) ?? "off"
        guard saved != "off" else { return }
        center.getNotificationSettings { settings in
            if settings.authorizationStatus == .authorized { self.apply(saved) }
        }
    }

    private func add(id: String, trigger: UNNotificationTrigger) {
        let content = UNMutableNotificationContent()
        content.title = "Theory Test IRL Multilanguage"
        content.body = Self.messages.randomElement() ?? Self.messages[0]
        content.sound = .default
        center.add(UNNotificationRequest(identifier: Self.idPrefix + id, content: content, trigger: trigger))
    }
}
