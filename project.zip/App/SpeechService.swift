import AVFoundation

/// Native text-to-speech, same behaviour as the Android build:
/// speaks with the voice of the requested language, and never reads a language
/// with the wrong voice (Arabic text read by the English voice is useless).
final class SpeechService: NSObject, AVSpeechSynthesizerDelegate {
    private let synthesizer = AVSpeechSynthesizer()
    var onFinished: (() -> Void)?
    /// Called once per language when the iPhone has no voice for it.
    var onMissingVoice: ((String) -> Void)?

    /// Preferred regional voice for each app language code.
    private static let preferredRegion: [String: [String]] = [
        "en": ["en-IE", "en-GB", "en-US"],
        "ar": ["ar-001", "ar-SA"],
        "pt": ["pt-BR", "pt-PT"],
        "zh": ["zh-CN", "zh-TW", "zh-HK"],
        "es": ["es-ES", "es-MX"],
        "fr": ["fr-FR", "fr-CA"],
        "hi": ["hi-IN"], "bn": ["bn-IN", "bn-BD"], "ur": ["ur-PK", "ur-IN"],
        "ml": ["ml-IN"], "pl": ["pl-PL"], "ro": ["ro-RO"], "uk": ["uk-UA"],
        "ru": ["ru-RU"], "lt": ["lt-LT"], "tr": ["tr-TR"], "sk": ["sk-SK"], "so": ["so-SO"],
    ]

    override init() {
        super.init()
        synthesizer.delegate = self
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio, options: [.duckOthers])
    }

    static func voice(for language: String) -> AVSpeechSynthesisVoice? {
        let base = String(language.split(separator: "-").first ?? Substring(language)).lowercased()
        let voices = AVSpeechSynthesisVoice.speechVoices()
        var candidates = [language]
        candidates += preferredRegion[base] ?? []
        for code in candidates {
            let matches = voices.filter { $0.language.caseInsensitiveCompare(code) == .orderedSame }
            if let best = matches.max(by: { $0.quality.rawValue < $1.quality.rawValue }) { return best }
        }
        // Any voice of the same language.
        let sameLanguage = voices.filter { $0.language.lowercased().hasPrefix(base + "-") || $0.language.lowercased() == base }
        return sameLanguage.max(by: { $0.quality.rawValue < $1.quality.rawValue })
    }

    func speak(_ text: String, language: String, rate: Double) {
        synthesizer.stopSpeaking(at: .immediate)
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { onFinished?(); return }
        guard let voice = Self.voice(for: language) else {
            onMissingVoice?(language)
            onFinished?()
            return
        }
        try? AVAudioSession.sharedInstance().setActive(true)
        let utterance = AVSpeechUtterance(string: trimmed)
        utterance.voice = voice
        // Android rate 1.0 = normal; iOS normal is AVSpeechUtteranceDefaultSpeechRate.
        let clamped = min(max(rate, 0.5), 2.0)
        let value = Float(clamped) * AVSpeechUtteranceDefaultSpeechRate
        utterance.rate = min(max(value, AVSpeechUtteranceMinimumSpeechRate), AVSpeechUtteranceMaximumSpeechRate)
        current = utterance
        synthesizer.speak(utterance)
    }

    /// Only the utterance currently playing may report "ended" to the page
    /// (a cancelled previous one must not reset the new one's Stop button).
    private var current: AVSpeechUtterance?

    func stop() {
        current = nil
        synthesizer.stopSpeaking(at: .immediate)
        onFinished?()
    }

    private func ended(_ utterance: AVSpeechUtterance) {
        guard utterance === current else { return }
        current = nil
        onFinished?()
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) { ended(utterance) }
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) { ended(utterance) }

    /// "ar: Majed (ar-001)" lines for every app language - used by the test build report.
    static func voiceReport() -> String {
        let codes = ["en-IE", "pl", "ro", "pt", "ar", "uk", "hi", "ur", "ml", "ru", "zh", "es", "lt", "fr", "tr", "bn", "sk", "so"]
        return codes.map { code in
            if let v = voice(for: code) { return "\(code): OK - \(v.name) (\(v.language))" }
            return "\(code): NO VOICE"
        }.joined(separator: "\n")
    }
}
