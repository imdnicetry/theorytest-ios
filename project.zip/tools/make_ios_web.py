#!/usr/bin/env python3
"""Make the iOS copy of the web app from the Android one.

Usage (from the iOS project root):
    python3 tools/make_ios_web.py <android-project>/app/src/main/assets/web

Copies the Android web bundle into ./web unchanged, then rewrites ONLY the few
sentences that name Android / Google Play (Apple rejects apps that mention
other platforms). Questions, translations, pictures, CSS and logic are copied
byte for byte. Writes web_checksums.txt so you can prove nothing else changed.
"""
import hashlib
import os
import shutil
import sys

# Each "old" text must appear exactly once in the main JS file.
IOS_WORDING = [
    ("Android can restore your saved app data through your Google account when device backup is enabled.",
     "iOS can restore your saved app data through iCloud Backup when it is enabled."),
    ("On Android, backup and restore may be handled by Google under the Google account and backup settings chosen on the device.",
     "On iPhone, backup and restore may be handled by Apple under the iCloud Backup settings chosen on the device."),
    ("The app requests notification permission where Android requires it. Users can turn reminders off inside the app or in Android Settings.",
     "The app requests notification permission where iOS requires it. Users can turn reminders off inside the app or in iPhone Settings."),
    ("Device-local information is protected by Android's application sandbox;",
     "Device-local information is protected by the iOS application sandbox;"),
    ("disable camera and notification permissions in Android Settings,",
     "disable camera and notification permissions in iPhone Settings,"),
    ("shown on the Driver Zone Ireland Google Play listing.",
     "shown on the Driver Zone Ireland App Store listing."),
]


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main(src):
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    dst = os.path.join(root, "web")
    if os.path.abspath(src) != os.path.abspath(dst):
        shutil.rmtree(dst, ignore_errors=True)
        shutil.copytree(src, dst)
    main_js = [f for f in os.listdir(os.path.join(dst, "assets")) if f.startswith("index-") and f.endswith(".js")]
    assert len(main_js) == 1, main_js
    js_path = os.path.join(dst, "assets", main_js[0])
    text = open(js_path, encoding="utf-8").read()
    for old, new in IOS_WORDING:
        if text.count(new) == 1 and old not in text:
            continue  # already converted
        assert text.count(old) == 1, f"expected once: {old[:60]}"
        text = text.replace(old, new)
    for word in ("Android Settings", "Google Play", "Google account"):
        assert word not in text, f"still mentions {word}"
    open(js_path, "w", encoding="utf-8").write(text)

    lines, changed = [], []
    for dirpath, _, files in os.walk(dst):
        for name in sorted(files):
            p = os.path.join(dirpath, name)
            rel = os.path.relpath(p, dst)
            digest = sha(p)
            lines.append(f"{digest}  {rel}")
            orig = os.path.join(src, rel)
            if not os.path.exists(orig) or sha(orig) != digest:
                changed.append(rel)
    lines.sort(key=lambda l: l.split("  ", 1)[1])
    open(os.path.join(root, "web_checksums.txt"), "w").write("\n".join(lines) + "\n")
    print(f"{len(lines)} files copied; changed for iOS wording only: {changed}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
